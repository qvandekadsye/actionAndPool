package vandekadsye.tanghe.ActionAndPool;

public interface Resource {
	
	/**
	 * @return the description of the resource as a String
	 */
	public String description();

}
