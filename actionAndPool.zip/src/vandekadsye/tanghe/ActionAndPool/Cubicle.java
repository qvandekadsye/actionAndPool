package vandekadsye.tanghe.ActionAndPool;

public class Cubicle implements Resource {

	@Override
	public String description() {
		
		return "A cubicle";
	}

}
