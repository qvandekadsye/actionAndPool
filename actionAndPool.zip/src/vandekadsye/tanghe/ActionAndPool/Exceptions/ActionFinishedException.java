package vandekadsye.tanghe.ActionAndPool.Exceptions;

public class ActionFinishedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Bien définir l'exception à hériter pour spécialiser
	 * Runtime Exception, le programmeur ne doit pas les catcher, il n'est pas imposer de le faire.
	 */

}
