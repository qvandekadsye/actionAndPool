package vandekadsye.tanghe.ActionAndPool;

public class Basket implements Resource {

	/**
	 * @return the description as a String
	 */
	@Override
	public String description() {
		
		return "A basket";
	}

}
